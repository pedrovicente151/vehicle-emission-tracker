#import <Foundation/Foundation.h>
@interface PodsDummy_FirebaseCoreDiagnostics : NSObject
@end
@implementation PodsDummy_FirebaseCoreDiagnostics
@end
