#import <Foundation/Foundation.h>
@interface PodsDummy_FirebaseCore : NSObject
@end
@implementation PodsDummy_FirebaseCore
@end
