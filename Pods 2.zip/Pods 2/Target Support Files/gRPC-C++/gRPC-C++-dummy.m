#import <Foundation/Foundation.h>
@interface PodsDummy_gRPC_C__ : NSObject
@end
@implementation PodsDummy_gRPC_C__
@end
