#import <Foundation/Foundation.h>
@interface PodsDummy_FirebaseInstallations : NSObject
@end
@implementation PodsDummy_FirebaseInstallations
@end
