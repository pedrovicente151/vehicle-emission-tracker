#import <Foundation/Foundation.h>
@interface PodsDummy_gRPC_Core : NSObject
@end
@implementation PodsDummy_gRPC_Core
@end
