//
//  WebViewController.swift
//  EcoCommute
//
//  Created by Pedro Vicente on 4/12/21.
//  Copyright © 2021 Fur Tree. All rights reserved.
//

import UIKit
import WebKit

class WebViewController: UIViewController {

    @IBOutlet weak var webView: WKWebView!
    
    override func viewDidLoad() {
        
        if let url = URL(string: "https://www.bbc.com/future/article/20200317-climate-change-cut-carbon-emissions-from-your-commute") {
        let urlRequest = URLRequest(url: url)
        
        webView.load(urlRequest)
        }


    }
}
