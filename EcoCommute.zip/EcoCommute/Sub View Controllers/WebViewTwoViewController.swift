//
//  WebViewTwoViewController.swift
//  EcoCommute
//
//  Created by Pedro Vicente on 4/12/21.
//  Copyright © 2021 Fur Tree. All rights reserved.
//

import UIKit
import WebKit

class WebViewTwoViewController: UIViewController {

    @IBOutlet weak var webView: WKWebView!
    
    override func viewDidLoad() {
        
        if let url = URL(string: "https://cleansd.org/2017/04/27/8-ways-to-reduce-your-ecological-footprint/") {
        let urlRequest = URLRequest(url: url)
        
        webView.load(urlRequest)
        }


    }
}
