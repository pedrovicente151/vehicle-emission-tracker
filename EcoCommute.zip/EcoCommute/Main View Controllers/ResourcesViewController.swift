//
//  ResourcesViewController.swift
//  EcoCommute
//
//  Created by Pedro Vicente on 4/12/21.
//  Copyright © 2021 Fur Tree. All rights reserved.
//

import UIKit
import WebKit

class ResourcesViewController: UIViewController {
    
    @IBOutlet weak var readMoreButtonOne: UIButton!
    
    @IBOutlet weak var readMoreButtonTwo: UIButton!
    
    let buttonColor = UIColor.init(red: 86/255, green: 200/255, blue: 241/255, alpha: 1)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUpUI()
    }
    
    func setUpUI() {
        readMoreButtonOne.layer.cornerRadius = 10
        readMoreButtonOne.backgroundColor = buttonColor
        readMoreButtonOne.setTitleColor(.white, for: .normal)
        
        readMoreButtonTwo.layer.cornerRadius = 10
        readMoreButtonTwo.backgroundColor = buttonColor
        readMoreButtonTwo.setTitleColor(.white, for: .normal)
    }
    
}
    
