//
//  DashboardViewController.swift
//  EcoCommute
//
//  Created by Pedro Vicente on 4/12/21.
//  Copyright © 2021 Fur Tree. All rights reserved.
//

import UIKit
import Charts

class DashboardViewController: UIViewController, ChartViewDelegate {

    var barChart = BarChartView()
    
    @IBOutlet weak var scoreLabel: UILabel!
    
    @IBOutlet weak var rewardsButton: UIButton!
    
    let buttonColor = UIColor.init(red: 86/255, green: 200/255, blue: 241/255, alpha: 1)
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        barChart.frame = CGRect(x: 0, y: 0, width: 300, height: 300)
        
        barChart.center = view.center
        view.addSubview(barChart)
        
        let set = BarChartDataSet(entries: [
            
            BarChartDataEntry(x: 1, y: 1.8),
            BarChartDataEntry(x: 2, y: 2.3),
            BarChartDataEntry(x: 3, y: 1.7),
            BarChartDataEntry(x: 4, y: 1.2),
        
        ])
        
        set.colors = ChartColorTemplates.liberty()
        
        let data = BarChartData(dataSet: set)
        
        barChart.data = data
        
        rewardsButton.layer.cornerRadius = 10
        rewardsButton.backgroundColor = buttonColor
        rewardsButton.setTitleColor(.white, for: .normal)
        
    }

}
