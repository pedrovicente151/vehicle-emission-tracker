//
//  HomeViewController.swift
//  EcoCommute
//
//  Created by Pedro Vicente on 4/12/21.
//  Copyright © 2021 Fur Tree. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import Firebase

class HomeViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {
    
    @IBOutlet weak var addressTextField: UITextField!
    @IBOutlet weak var goButton: UIButton!
    @IBOutlet weak var mapView: MKMapView!
    
    var locationManager = CLLocationManager()
    
    let buttonColor = UIColor.init(red: 86/255, green: 200/255, blue: 241/255, alpha: 1)
    
    override func viewDidLoad() {
        super.viewDidLoad()

//        let location = CLLocationCoordinate2D(latitude: 43.6532, longitude: -79.3832)
//
//        let region = MKCoordinateRegion(center: location, span: MKCoordinateSpan(latitudeDelta: 5, longitudeDelta: 0.005))
//
//        self.mapView.setRegion(region, animated: true)
        
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestAlwaysAuthorization()
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        
        mapView.delegate = self
        
        setUpUI()
    }
    
    
    @IBAction func goButtonTapped(_ sender: Any) {
        getAddress()
    }
    
    func setUpUI() {
        goButton.layer.cornerRadius = 5
        goButton.backgroundColor = buttonColor
        goButton.setTitleColor(.white, for: .normal)
    }
    
    func getAddress() {
        let geoCoder = CLGeocoder()
        geoCoder.geocodeAddressString(addressTextField.text!) { (placemarks, error) in
            guard let placemarks = placemarks, let location = placemarks.first?.location
            else {
                
                let alert = UIAlertController(title: "Ops!", message: "Location not found. Please enter a valid address.", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                return
            }
            
            self.mapThis(destinationCoordinate: location.coordinate)
            
            self.calculateDistanceDifference(destinationLatitude: Float(location.coordinate.latitude), destinationLongitude: Float(location.coordinate.longitude))
        }
    }
    
    func calculateDistanceDifference(destinationLatitude: Float, destinationLongitude: Float) {
        let myCoordinate = (self.locationManager.location?.coordinate)!
        
        let xValue = pow((destinationLongitude - Float(myCoordinate.longitude)), 2)
        let yValue = pow((destinationLatitude - Float(myCoordinate.latitude)), 2)
        
        let sumValues = (xValue + yValue).squareRoot()
        
        // SAVE TO FIREBASE
        
        
        
        
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print(locations)
    }
    
    func mapThis(destinationCoordinate: CLLocationCoordinate2D) {
        let sourceCoordinate = (locationManager.location?.coordinate)!
        
        let sourcePlacemark = MKPlacemark(coordinate: sourceCoordinate)
        let destinationPlacemark = MKPlacemark(coordinate: destinationCoordinate)
        
        let sourceItem = MKMapItem(placemark: sourcePlacemark)
        let destinationItem = MKMapItem(placemark: destinationPlacemark)
        
        let destinationRequest = MKDirections.Request()
        destinationRequest.source = sourceItem
        destinationRequest.destination = destinationItem
        
        destinationRequest.transportType = .automobile
        destinationRequest.requestsAlternateRoutes = true
        
        let directions = MKDirections(request: destinationRequest)
        directions.calculate { (response, error) in
            guard let response = response else {
                if error != nil {
                    print("Ops! Something went wrong")
                }
                return
            }
            // Only return one route
            let route = response.routes[0]
            self.mapView.addOverlay(route.polyline)
            self.mapView.setVisibleMapRect(route.polyline.boundingMapRect, animated: true)
        }
    }
    
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        let render = MKPolylineRenderer(overlay: overlay as! MKPolyline)
        render.strokeColor = buttonColor
        return render
    }
}
