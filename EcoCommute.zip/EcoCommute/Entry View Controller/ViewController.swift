//
//  ViewController.swift
//  EcoCommute
//
//  Created by Pedro Vicente on 4/12/21.
//  Copyright © 2021 Fur Tree. All rights reserved.
//

import UIKit
import Firebase
import GoogleSignIn
import FirebaseAuth
import FirebaseFirestore

class ViewController: UIViewController {
    
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var signUpButton: UIButton!
    
    
    let buttonColor = UIColor.init(red: 86/255, green: 200/255, blue: 241/255, alpha: 1)

    override func viewDidLoad() {
        super.viewDidLoad()
        
        GIDSignIn.sharedInstance()?.presentingViewController = self
        
        // Hides Keyboard when Screen is Tapped
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(self.viewTapped))
        self.view.addGestureRecognizer(tapGestureRecognizer)
        
        signUpButton.layer.cornerRadius = 10
        signUpButton.backgroundColor = buttonColor
        signUpButton.setTitleColor(.white, for: .normal)
        
        styleTextField(emailTextField)
        styleTextField(passwordTextField)
        
    }
    
    
    @IBAction func signUpTapped(_ sender: Any) {
        
        let email = emailTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        let password = passwordTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        
        
        Auth.auth().createUser(withEmail: email, password: password) { (result, err) in
            
            // Check for errors
                if err != nil {
                    //  There was an error creating a yser
                    let alert = UIAlertController(title: "Ops!", message: "Please enter a valid email.", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    return
                }
                else {
                    // User was created succesfully, now store first and last name
                    let db = Firestore.firestore()
            
                db.collection("users").document(result!.user.uid).setData(["email":email])
                    
                    // Transition to home screen
                    self.transitionToHome()
                    
                }
                
            }
    }
    
    
    func transitionToHome() {
        
        let homeViewController = storyboard?.instantiateViewController(identifier: "HomeVC") as? UITabBarController
        
        view.window?.rootViewController = homeViewController
        view.window?.makeKeyAndVisible()
    }
    
    func styleTextField(_ textfield:UITextField) {
        
        // Create the bottom line
        let bottomLine = CALayer()
        
        bottomLine.frame = CGRect(x: 0, y: textfield.frame.height - 2, width: textfield.frame.width, height: 2)
        
        bottomLine.backgroundColor = buttonColor.cgColor
        
        // Remove border on text field
        textfield.borderStyle = .none
        
        // Add the line to the text field
        textfield.layer.addSublayer(bottomLine)
        
        
    }
    
    
//     Hides Keyboard when Screen is Tapped
    @objc func viewTapped(){
        emailTextField.resignFirstResponder()
        passwordTextField.resignFirstResponder()
    }


}
